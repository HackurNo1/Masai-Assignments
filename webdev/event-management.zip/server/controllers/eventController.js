const Event = require("../models/Event")
const User = require("../models/User")

// @desc    Create a new event
// @route   POST /api/events
// @access  Private
exports.createEvent = async (req, res, next) => {
  try {
    const { title, description, date, time, location, isPublic, category } = req.body

    const event = await Event.create({
      title,
      description,
      date,
      time,
      location,
      isPublic,
      category,
      creator: req.user.id,
      attendees: [{ user: req.user.id, status: "attending", responseDate: Date.now() }],
    })

    // Add event to user's created events
    await User.findByIdAndUpdate(req.user.id, {
      $push: { eventsCreated: event._id },
    })

    res.status(201).json(event)
  } catch (error) {
    next(error)
  }
}

// @desc    Get all events
// @route   GET /api/events
// @access  Public
exports.getEvents = async (req, res, next) => {
  try {
    const events = await Event.find({ isPublic: true }).populate("creator", "name email").sort({ date: 1 })

    res.json(events)
  } catch (error) {
    next(error)
  }
}

// @desc    Get single event
// @route   GET /api/events/:id
// @access  Public
exports.getEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id)
      .populate("creator", "name email")
      .populate("attendees.user", "name email")

    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }

    res.json(event)
  } catch (error) {
    next(error)
  }
}

// @desc    Update event
// @route   PUT /api/events/:id
// @access  Private
exports.updateEvent = async (req, res, next) => {
  try {
    let event = await Event.findById(req.params.id)

    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }

    // Make sure user is event creator
    if (event.creator.toString() !== req.user.id) {
      return res.status(401).json({ message: "Not authorized to update this event" })
    }

    event = await Event.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    })

    res.json(event)
  } catch (error) {
    next(error)
  }
}

// @desc    Delete event
// @route   DELETE /api/events/:id
// @access  Private
exports.deleteEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id)

    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }

    // Make sure user is event creator
    if (event.creator.toString() !== req.user.id) {
      return res.status(401).json({ message: "Not authorized to delete this event" })
    }

    await event.deleteOne()

    // Remove event from user's created events
    await User.findByIdAndUpdate(req.user.id, {
      $pull: { eventsCreated: req.params.id },
    })

    res.json({ message: "Event removed" })
  } catch (error) {
    next(error)
  }
}

// @desc    RSVP to an event
// @route   POST /api/events/:id/rsvp
// @access  Private
exports.rsvpEvent = async (req, res, next) => {
  try {
    const { status } = req.body

    if (!["attending", "maybe", "not attending"].includes(status)) {
      return res.status(400).json({ message: "Invalid RSVP status" })
    }

    const event = await Event.findById(req.params.id)

    if (!event) {
      return res.status(404).json({ message: "Event not found" })
    }

    // Check if user is already in attendees list
    const attendeeIndex = event.attendees.findIndex((attendee) => attendee.user.toString() === req.user.id)

    if (attendeeIndex > -1) {
      // Update existing RSVP
      event.attendees[attendeeIndex].status = status
      event.attendees[attendeeIndex].responseDate = Date.now()
    } else {
      // Add new RSVP
      event.attendees.push({
        user: req.user.id,
        status,
        responseDate: Date.now(),
      })
    }

    await event.save()

    // Update user's attending events
    const user = await User.findById(req.user.id)
    const eventIndex = user.eventsAttending.findIndex((e) => e.event.toString() === req.params.id)

    if (eventIndex > -1) {
      user.eventsAttending[eventIndex].status = status
    } else {
      user.eventsAttending.push({
        event: req.params.id,
        status,
      })
    }

    await user.save()

    res.json(event)
  } catch (error) {
    next(error)
  }
}
