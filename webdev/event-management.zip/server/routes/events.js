const express = require("express")
const router = express.Router()
const {
  createEvent,
  getEvents,
  getEvent,
  updateEvent,
  deleteEvent,
  rsvpEvent,
} = require("../controllers/eventController")
const auth = require("../middleware/auth")

router.route("/").get(getEvents).post(auth, createEvent)

router.route("/:id").get(getEvent).put(auth, updateEvent).delete(auth, deleteEvent)

router.post("/:id/rsvp", auth, rsvpEvent)

module.exports = router
