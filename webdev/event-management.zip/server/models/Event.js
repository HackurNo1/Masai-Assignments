const mongoose = require("mongoose")

const EventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "Please provide an event title"],
    trim: true,
  },
  description: {
    type: String,
    required: [true, "Please provide an event description"],
  },
  date: {
    type: Date,
    required: [true, "Please provide an event date"],
  },
  time: {
    start: {
      type: String,
      required: [true, "Please provide a start time"],
    },
    end: {
      type: String,
    },
  },
  location: {
    address: {
      type: String,
      required: [true, "Please provide an address"],
    },
    city: {
      type: String,
      required: [true, "Please provide a city"],
    },
    coordinates: {
      lat: Number,
      lng: Number,
    },
  },
  banner: {
    type: String,
    default: "default-event-banner.jpg",
  },
  creator: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  attendees: [
    {
      user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
      status: {
        type: String,
        enum: ["attending", "maybe", "not attending", "no response"],
        default: "no response",
      },
      responseDate: {
        type: Date,
      },
    },
  ],
  isPublic: {
    type: Boolean,
    default: true,
  },
  category: {
    type: String,
    enum: ["social", "business", "education", "sports", "other"],
    default: "social",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
})

module.exports = mongoose.model("Event", EventSchema)
