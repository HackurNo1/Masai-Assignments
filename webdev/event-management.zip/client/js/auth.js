// Import API functions
import { authAPI } from "./api.js"

// DOM Elements
const signupForm = document.getElementById("signup-form")
const loginForm = document.getElementById("login-form")
const togglePasswordBtns = document.querySelectorAll(".toggle-password")

// Helper Functions
function showError(message) {
  // Create error element if it doesn't exist
  let errorElement = document.querySelector(".auth-error")
  if (!errorElement) {
    errorElement = document.createElement("div")
    errorElement.className = "auth-error"
    errorElement.style.color = "var(--danger-color)"
    errorElement.style.marginBottom = "1rem"
    errorElement.style.textAlign = "center"

    // Insert before the form
    const form = document.querySelector(".auth-form")
    form.insertBefore(errorElement, form.firstChild)
  }

  errorElement.textContent = message
}

function validatePassword(password) {
  // Check password strength
  const hasMinLength = password.length >= 8
  const hasUpperCase = /[A-Z]/.test(password)
  const hasLowerCase = /[a-z]/.test(password)
  const hasNumber = /[0-9]/.test(password)
  const hasSpecialChar = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)

  // Calculate strength score (0-4)
  let score = 0
  if (hasMinLength) score++
  if (hasUpperCase && hasLowerCase) score++
  if (hasNumber) score++
  if (hasSpecialChar) score++

  return {
    score,
    isValid: score >= 2 && hasMinLength,
  }
}

function updatePasswordStrength(password) {
  const strengthMeter = document.querySelector(".strength-meter")
  const strengthText = document.querySelector(".strength-text")

  if (!strengthMeter || !strengthText) return

  const { score, isValid } = validatePassword(password)

  // Update strength meter
  strengthMeter.style.width = `${score * 25}%`

  // Update color based on score
  let color = "var(--danger-color)"
  let text = "Weak"

  if (score === 2) {
    color = "var(--warning-color)"
    text = "Fair"
  } else if (score === 3) {
    color = "var(--success-color)"
    text = "Good"
  } else if (score === 4) {
    color = "var(--success-color)"
    text = "Strong"
  }

  strengthMeter.style.backgroundColor = color
  strengthText.textContent = `Password strength: ${text}`
  strengthText.style.color = color
}

// Event Listeners
if (togglePasswordBtns) {
  togglePasswordBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const passwordInput = btn.parentElement.querySelector("input")
      const type = passwordInput.getAttribute("type") === "password" ? "text" : "password"
      passwordInput.setAttribute("type", type)

      // Toggle icon
      const icon = btn.querySelector("i")
      icon.classList.toggle("fa-eye")
      icon.classList.toggle("fa-eye-slash")
    })
  })
}

// Signup Form
if (signupForm) {
  const passwordInput = document.getElementById("password")
  const confirmPasswordInput = document.getElementById("confirm-password")

  // Update password strength on input
  passwordInput.addEventListener("input", () => {
    updatePasswordStrength(passwordInput.value)
  })

  signupForm.addEventListener("submit", async (e) => {
    e.preventDefault()

    const name = document.getElementById("name").value
    const email = document.getElementById("email").value
    const password = passwordInput.value
    const confirmPassword = confirmPasswordInput.value

    // Validate passwords match
    if (password !== confirmPassword) {
      showError("Passwords do not match")
      return
    }

    // Validate password strength
    const { isValid } = validatePassword(password)
    if (!isValid) {
      showError("Password must be at least 8 characters and include a mix of letters, numbers, or special characters")
      return
    }

    try {
      const userData = { name, email, password }
      const response = await authAPI.register(userData)

      // Store token and user data
      localStorage.setItem("token", response.token)
      localStorage.setItem(
        "user",
        JSON.stringify({
          id: response._id,
          name: response.name,
          email: response.email,
        }),
      )

      // Redirect to dashboard
      window.location.href = "dashboard.html"
    } catch (error) {
      showError(error.message || "Failed to create account. Please try again.")
    }
  })
}

// Login Form
if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault()

    const email = document.getElementById("email").value
    const password = document.getElementById("password").value

    try {
      const credentials = { email, password }
      const response = await authAPI.login(credentials)

      // Store token and user data
      localStorage.setItem("token", response.token)
      localStorage.setItem(
        "user",
        JSON.stringify({
          id: response._id,
          name: response.name,
          email: response.email,
        }),
      )

      // Redirect to dashboard
      window.location.href = "dashboard.html"
    } catch (error) {
      showError(error.message || "Invalid email or password")
    }
  })
}
