// Import API functions
import { eventsAPI } from "./api.js"

// DOM Elements
const eventForm = document.getElementById("event-form")
const nextStepButtons = document.querySelectorAll(".next-step")
const prevStepButtons = document.querySelectorAll(".prev-step")
const progressSteps = document.querySelectorAll(".progress-step")
const wizardSteps = document.querySelectorAll(".wizard-step")
const eventBannerInput = document.getElementById("event-banner")
const bannerPreview = document.getElementById("banner-preview")
const userDropdownToggle = document.getElementById("user-dropdown-toggle")
const userDropdown = document.getElementById("user-dropdown")
const logoutBtn = document.getElementById("logout-btn")

// Preview elements
const previewTitle = document.getElementById("preview-title")
const previewDate = document.getElementById("preview-date")
const previewTime = document.getElementById("preview-time")
const previewLocation = document.getElementById("preview-location")
const previewCategory = document.getElementById("preview-category")
const previewDescription = document.getElementById("preview-description")
const previewBanner = document.getElementById("preview-banner")

// Check if user is logged in
function checkAuth() {
  const token = localStorage.getItem("token")
  const user = JSON.parse(localStorage.getItem("user") || "{}")

  if (!token || !user.id) {
    // Redirect to login page if not logged in
    window.location.href = "login.html"
    return null
  }

  return { token, user }
}

// Initialize event creation page
function initEventCreation() {
  const auth = checkAuth()
  if (!auth) return

  // Update user name in header
  const userNameElement = document.querySelector(".user-name")
  if (userNameElement) {
    userNameElement.textContent = auth.user.name
  }
}

// Navigate to next step in wizard
function goToNextStep(currentStepBtn) {
  const currentStep = Number.parseInt(currentStepBtn.closest(".wizard-step").dataset.step)
  const nextStep = currentStep + 1

  // Validate current step
  if (!validateStep(currentStep)) {
    return
  }

  // Update progress steps
  progressSteps.forEach((step) => {
    const stepNumber = Number.parseInt(step.dataset.step)
    if (stepNumber === currentStep) {
      step.classList.add("completed")
    }
    if (stepNumber === nextStep) {
      step.classList.add("active")
    }
  })

  // Show next step
  wizardSteps.forEach((step) => {
    step.classList.remove("active")
    if (Number.parseInt(step.dataset.step) === nextStep) {
      step.classList.add("active")
    }
  })

  // Update preview if going to review step
  if (nextStep === 5) {
    updateEventPreview()
  }
}

// Navigate to previous step in wizard
function goToPrevStep(currentStepBtn) {
  const currentStep = Number.parseInt(currentStepBtn.closest(".wizard-step").dataset.step)
  const prevStep = currentStep - 1

  // Update progress steps
  progressSteps.forEach((step) => {
    const stepNumber = Number.parseInt(step.dataset.step)
    if (stepNumber === currentStep) {
      step.classList.remove("active")
    }
    if (stepNumber === prevStep) {
      step.classList.remove("completed")
      step.classList.add("active")
    }
  })

  // Show previous step
  wizardSteps.forEach((step) => {
    step.classList.remove("active")
    if (Number.parseInt(step.dataset.step) === prevStep) {
      step.classList.add("active")
    }
  })
}

// Validate current step
function validateStep(step) {
  const stepElement = document.querySelector(`.wizard-step[data-step="${step}"]`)
  const requiredFields = stepElement.querySelectorAll("[required]")

  let isValid = true

  requiredFields.forEach((field) => {
    if (!field.value.trim()) {
      field.classList.add("invalid")
      isValid = false
    } else {
      field.classList.remove("invalid")
    }
  })

  if (!isValid) {
    // Show error message
    let errorElement = stepElement.querySelector(".step-error")
    if (!errorElement) {
      errorElement = document.createElement("div")
      errorElement.className = "step-error"
      errorElement.style.color = "var(--danger-color)"
      errorElement.style.marginTop = "1rem"
      errorElement.style.textAlign = "center"
      stepElement.querySelector(".wizard-buttons").before(errorElement)
    }

    errorElement.textContent = "Please fill in all required fields"
  }

  return isValid
}

// Update event preview
function updateEventPreview() {
  const title = document.getElementById("event-title").value
  const date = document.getElementById("event-date").value
  const startTime = document.getElementById("event-start-time").value
  const endTime = document.getElementById("event-end-time").value
  const address = document.getElementById("event-address").value
  const city = document.getElementById("event-city").value
  const category = document.getElementById("event-category").value
  const description = document.getElementById("event-description").value

  // Format date
  const formattedDate = date
    ? new Date(date).toLocaleDateString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      })
    : ""

  // Format time
  const formattedTime = startTime ? `${formatTime(startTime)}${endTime ? " - " + formatTime(endTime) : ""}` : ""

  // Format location
  const formattedLocation = address && city ? `${address}, ${city}` : ""

  // Format category
  const formattedCategory = category ? category.charAt(0).toUpperCase() + category.slice(1) : ""

  // Update preview elements
  if (previewTitle) previewTitle.textContent = title || "Event Title"
  if (previewDate) previewDate.textContent = formattedDate || "Date"
  if (previewTime) previewTime.textContent = formattedTime || "Time"
  if (previewLocation) previewLocation.textContent = formattedLocation || "Location"
  if (previewCategory) previewCategory.textContent = formattedCategory || "Category"
  if (previewDescription) previewDescription.textContent = description || "Event description will appear here."
}

// Format time from 24h to 12h format
function formatTime(time) {
  if (!time) return ""

  const [hours, minutes] = time.split(":")
  const hour = Number.parseInt(hours)
  const ampm = hour >= 12 ? "PM" : "AM"
  const formattedHour = hour % 12 || 12

  return `${formattedHour}:${minutes} ${ampm}`
}

// Event Listeners
document.addEventListener("DOMContentLoaded", () => {
  // Initialize event creation
  initEventCreation()

  // Next step buttons
  if (nextStepButtons) {
    nextStepButtons.forEach((button) => {
      button.addEventListener("click", () => {
        goToNextStep(button)
      })
    })
  }

  // Previous step buttons
  if (prevStepButtons) {
    prevStepButtons.forEach((button) => {
      button.addEventListener("click", () => {
        goToPrevStep(button)
      })
    })
  }

  // Event banner upload
  if (eventBannerInput && bannerPreview) {
    eventBannerInput.addEventListener("change", (e) => {
      const file = e.target.files[0]
      if (file) {
        const reader = new FileReader()
        reader.onload = (e) => {
          bannerPreview.innerHTML = `<img src="${e.target.result}" alt="Event Banner">`
          if (previewBanner) {
            previewBanner.src = e.target.result
          }
        }
        reader.readAsDataURL(file)
      }
    })
  }

  // Event form submission
  if (eventForm) {
    eventForm.addEventListener("submit", async (e) => {
      e.preventDefault()

      const auth = checkAuth()
      if (!auth) return

      // Get form data
      const formData = new FormData(eventForm)
      const eventData = {
        title: formData.get("title"),
        description: formData.get("description"),
        date: formData.get("date"),
        time: {
          start: formData.get("time.start"),
          end: formData.get("time.end") || null,
        },
        location: {
          address: formData.get("location.address"),
          city: formData.get("location.city"),
        },
        category: formData.get("category"),
        isPublic: formData.get("isPublic") === "true",
      }

      try {
        // Create event
        const event = await eventsAPI.createEvent(eventData, auth.token)

        // Redirect to event details page
        window.location.href = `event-details.html?id=${event._id}`
      } catch (error) {
        console.error("Error creating event:", error)
        // Show error message
        alert("Failed to create event. Please try again.")
      }
    })
  }

  // User dropdown toggle
  if (userDropdownToggle && userDropdown) {
    userDropdownToggle.addEventListener("click", (e) => {
      e.preventDefault()
      userDropdown.classList.toggle("active")
    })

    // Close dropdown when clicking outside
    document.addEventListener("click", (e) => {
      if (!userDropdownToggle.contains(e.target) && !userDropdown.contains(e.target)) {
        userDropdown.classList.remove("active")
      }
    })
  }

  // Logout button
  if (logoutBtn) {
    logoutBtn.addEventListener("click", (e) => {
      e.preventDefault()

      // Clear local storage
      localStorage.removeItem("token")
      localStorage.removeItem("user")

      // Redirect to login page
      window.location.href = "login.html"
    })
  }
})
