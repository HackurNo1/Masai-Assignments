// Import API functions
import { eventsAPI } from "./api.js"

// DOM Elements
const eventTitle = document.getElementById("event-title")
const eventDate = document.getElementById("event-date")
const eventTime = document.getElementById("event-time")
const eventLocation = document.getElementById("event-location")
const eventCreator = document.getElementById("event-creator")
const eventDescription = document.getElementById("event-description")
const eventFullAddress = document.getElementById("event-full-address")
const eventBanner = document.getElementById("event-banner")
const attendeesCount = document.getElementById("attendees-count")
const eventAttendees = document.getElementById("event-attendees")
const hostName = document.getElementById("host-name")
const hostEventsCount = document.getElementById("host-events-count")
const hostAvatar = document.getElementById("host-avatar")
const rsvpSection = document.getElementById("rsvp-section")
const userDropdownToggle = document.getElementById("user-dropdown-toggle")
const userDropdown = document.getElementById("user-dropdown")
const logoutBtn = document.getElementById("logout-btn")

// Check if user is logged in
function checkAuth() {
  const token = localStorage.getItem("token")
  const user = JSON.parse(localStorage.getItem("user") || "{}")

  if (!token || !user.id) {
    // Redirect to login page if not logged in
    window.location.href = "login.html"
    return null
  }

  return { token, user }
}

// Get event ID from URL
function getEventId() {
  const urlParams = new URLSearchParams(window.location.search)
  return urlParams.get("id")
}

// Initialize event details page
async function initEventDetails() {
  const auth = checkAuth()
  if (!auth) return

  const eventId = getEventId()
  if (!eventId) {
    window.location.href = "dashboard.html"
    return
  }

  // Update user name in header
  const userNameElement = document.querySelector(".user-name")
  if (userNameElement) {
    userNameElement.textContent = auth.user.name
  }

  try {
    // Fetch event details
    const event = await eventsAPI.getEvent(eventId)

    // Render event details
    renderEventDetails(event, auth.user.id)

    // Set up RSVP buttons
    setupRsvpButtons(event, auth)
  } catch (error) {
    console.error("Error loading event details:", error)
    // Show error message
    alert("Failed to load event details. Please try again.")
  }
}

// Render event details
function renderEventDetails(event, userId) {
  // Format date
  const eventDateObj = new Date(event.date)
  const formattedDate = eventDateObj.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  // Format time
  const formattedTime = `${formatTime(event.time.start)}${event.time.end ? " - " + formatTime(event.time.end) : ""}`

  // Update page elements
  if (eventTitle) eventTitle.textContent = event.title
  if (eventDate) eventDate.textContent = formattedDate
  if (eventTime) eventTime.textContent = formattedTime
  if (eventLocation) eventLocation.textContent = `${event.location.address}, ${event.location.city}`
  if (eventCreator) eventCreator.textContent = `Organized by ${event.creator.name}`
  if (eventDescription) eventDescription.textContent = event.description
  if (eventFullAddress) eventFullAddress.textContent = `${event.location.address}, ${event.location.city}`
  if (eventBanner) eventBanner.src = event.banner || "assets/default-event-banner.jpg"

  // Update attendees count
  const attending = event.attendees.filter((a) => a.status === "attending").length
  if (attendeesCount) attendeesCount.textContent = attending

  // Render attendees list
  renderAttendees(event.attendees, eventAttendees)

  // Update host information
  if (hostName) hostName.textContent = event.creator.name
  if (hostEventsCount) hostEventsCount.textContent = "1 event created" // This would need to be fetched from API
  if (hostAvatar) hostAvatar.src = "assets/default-profile.jpg" // This would need to be fetched from API
}

// Render attendees list
function renderAttendees(attendees, container) {
  if (!container) return

  // Clear container
  container.innerHTML = ""

  const attendingUsers = attendees.filter((a) => a.status === "attending")

  if (attendingUsers.length === 0) {
    // Show empty state
    container.innerHTML = `
      <div class="empty-attendees">
        <p>No attendees yet. Be the first to RSVP!</p>
      </div>
    `
    return
  }

  // Create attendees list
  const attendeesList = document.createElement("div")
  attendeesList.className = "attendees-grid"

  attendingUsers.forEach((attendee) => {
    const attendeeItem = document.createElement("div")
    attendeeItem.className = "attendee-item"
    attendeeItem.innerHTML = `
      <img src="assets/default-profile.jpg" alt="${attendee.user.name}" class="attendee-avatar">
      <span class="attendee-name">${attendee.user.name}</span>
    `
    attendeesList.appendChild(attendeeItem)
  })

  container.appendChild(attendeesList)
}

// Set up RSVP buttons
function setupRsvpButtons(event, auth) {
  if (!rsvpSection) return

  // Check if user is the creator
  if (event.creator._id === auth.user.id) {
    // Hide RSVP section for creator
    rsvpSection.innerHTML = `
      <div class="host-badge">
        <i class="fas fa-star"></i> You're hosting this event
      </div>
      <div class="event-actions-secondary">
        <button class="btn btn-outline btn-icon" title="Edit Event">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn btn-outline btn-icon" title="Delete Event">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    `
    return
  }

  // Find user's RSVP status
  const userAttendee = event.attendees.find((a) => a.user._id === auth.user.id)
  const userStatus = userAttendee ? userAttendee.status : null

  // Update RSVP buttons
  const rsvpButtons = rsvpSection.querySelectorAll(".rsvp-btn")
  rsvpButtons.forEach((button) => {
    const status = button.dataset.status

    // Reset all buttons
    button.classList.remove("btn-primary")
    button.classList.add("btn-outline")

    // Highlight active status
    if (status === userStatus) {
      button.classList.remove("btn-outline")
      button.classList.add("btn-primary")
    }

    // Add click event
    button.addEventListener("click", async () => {
      try {
        await eventsAPI.rsvpEvent(event._id, status, auth.token)

        // Update UI
        rsvpButtons.forEach((btn) => {
          btn.classList.remove("btn-primary")
          btn.classList.add("btn-outline")
        })
        button.classList.remove("btn-outline")
        button.classList.add("btn-primary")

        // Refresh page to update attendees list
        window.location.reload()
      } catch (error) {
        console.error("Error updating RSVP:", error)
        alert("Failed to update RSVP. Please try again.")
      }
    })
  })
}

// Format time from 24h to 12h format
function formatTime(time) {
  if (!time) return ""

  const [hours, minutes] = time.split(":")
  const hour = Number.parseInt(hours)
  const ampm = hour >= 12 ? "PM" : "AM"
  const formattedHour = hour % 12 || 12

  return `${formattedHour}:${minutes} ${ampm}`
}

// Event Listeners
document.addEventListener("DOMContentLoaded", () => {
  // Initialize event details
  initEventDetails()

  // User dropdown toggle
  if (userDropdownToggle && userDropdown) {
    userDropdownToggle.addEventListener("click", (e) => {
      e.preventDefault()
      userDropdown.classList.toggle("active")
    })

    // Close dropdown when clicking outside
    document.addEventListener("click", (e) => {
      if (!userDropdownToggle.contains(e.target) && !userDropdown.contains(e.target)) {
        userDropdown.classList.remove("active")
      }
    })
  }

  // Logout button
  if (logoutBtn) {
    logoutBtn.addEventListener("click", (e) => {
      e.preventDefault()

      // Clear local storage
      localStorage.removeItem("token")
      localStorage.removeItem("user")

      // Redirect to login page
      window.location.href = "login.html"
    })
  }
})
