// Base API URL
const API_URL = "http://localhost:5000/api"

// Helper function for making API requests
async function apiRequest(endpoint, method = "GET", data = null, token = null) {
  const headers = {
    "Content-Type": "application/json",
  }

  if (token) {
    headers["Authorization"] = `Bearer ${token}`
  }

  const config = {
    method,
    headers,
  }

  if (data && (method === "POST" || method === "PUT")) {
    config.body = JSON.stringify(data)
  }

  try {
    const response = await fetch(`${API_URL}${endpoint}`, config)
    const responseData = await response.json()

    if (!response.ok) {
      throw new Error(responseData.message || "Something went wrong")
    }

    return responseData
  } catch (error) {
    console.error("API Error:", error)
    throw error
  }
}

// Auth API
const authAPI = {
  register: (userData) => apiRequest("/auth/register", "POST", userData),
  login: (credentials) => apiRequest("/auth/login", "POST", credentials),
  getProfile: (token) => apiRequest("/auth/me", "GET", null, token),
}

// Events API
const eventsAPI = {
  getEvents: () => apiRequest("/events"),
  getEvent: (id) => apiRequest(`/events/${id}`),
  createEvent: (eventData, token) => apiRequest("/events", "POST", eventData, token),
  updateEvent: (id, eventData, token) => apiRequest(`/events/${id}`, "PUT", eventData, token),
  deleteEvent: (id, token) => apiRequest(`/events/${id}`, "DELETE", null, token),
  rsvpEvent: (id, status, token) => apiRequest(`/events/${id}/rsvp`, "POST", { status }, token),
}

// Export the API modules
export { authAPI, eventsAPI }
