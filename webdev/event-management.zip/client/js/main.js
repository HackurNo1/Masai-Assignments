// Main JavaScript file for the landing page

document.addEventListener("DOMContentLoaded", () => {
  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()

      const targetId = this.getAttribute("href")
      if (targetId === "#") return

      const targetElement = document.querySelector(targetId)
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 80, // Adjust for header height
          behavior: "smooth",
        })
      }
    })
  })

  // Check if user is logged in
  const token = localStorage.getItem("token")
  const user = JSON.parse(localStorage.getItem("user") || "{}")

  // Update navigation based on auth status
  if (token && user.id) {
    // User is logged in, show dashboard link
    const navLinks = document.querySelector(".main-nav ul")
    if (navLinks) {
      // Replace login/signup with dashboard link
      navLinks.innerHTML = navLinks.innerHTML.replace(
        `
        <li><a href="login.html" class="btn btn-outline">Login</a></li>
        <li><a href="signup.html" class="btn btn-primary">Sign Up</a></li>
      `,
        `
        <li><a href="dashboard.html" class="btn btn-primary">Dashboard</a></li>
      `,
      )
    }
  }

  // Add animation to feature cards
  const featureCards = document.querySelectorAll(".feature-card")
  if (featureCards.length) {
    featureCards.forEach((card, index) => {
      // Add staggered animation delay
      card.style.animationDelay = `${index * 0.1}s`
      card.classList.add("animate-in")
    })
  }
})
