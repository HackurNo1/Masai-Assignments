// Import API functions
import { eventsAPI } from "./api.js"

// DOM Elements
const userNameElement = document.getElementById("user-name")
const userDropdownToggle = document.getElementById("user-dropdown-toggle")
const userDropdown = document.getElementById("user-dropdown")
const logoutBtn = document.getElementById("logout-btn")
const tabButtons = document.querySelectorAll(".tab-btn")
const tabContents = document.querySelectorAll(".tab-content")
const upcomingEventsContainer = document.getElementById("upcoming-events")
const createdEventsContainer = document.getElementById("created-events")
const invitationsContainer = document.getElementById("invitations")
const upcomingEventsCount = document.getElementById("upcoming-events-count")
const totalAttendeesCount = document.getElementById("total-attendees-count")
const createdEventsCount = document.getElementById("created-events-count")

// Check if user is logged in
function checkAuth() {
  const token = localStorage.getItem("token")
  const user = JSON.parse(localStorage.getItem("user") || "{}")

  if (!token || !user.id) {
    // Redirect to login page if not logged in
    window.location.href = "login.html"
    return null
  }

  return { token, user }
}

// Initialize dashboard
async function initDashboard() {
  const auth = checkAuth()
  if (!auth) return

  // Update user name
  if (userNameElement) {
    userNameElement.textContent = auth.user.name.split(" ")[0]
  }

  // Load events data
  try {
    const events = await eventsAPI.getEvents()

    // Filter events
    const now = new Date()
    const upcomingEvents = events.filter((event) => new Date(event.date) >= now)
    const userCreatedEvents = events.filter((event) => event.creator._id === auth.user.id)
    const userInvitedEvents = events.filter((event) => {
      const isAttendee = event.attendees.some(
        (attendee) => attendee.user === auth.user.id && attendee.status === "no response",
      )
      return isAttendee && event.creator._id !== auth.user.id
    })

    // Update stats
    if (upcomingEventsCount) upcomingEventsCount.textContent = upcomingEvents.length
    if (createdEventsCount) createdEventsCount.textContent = userCreatedEvents.length

    // Calculate total attendees
    let totalAttendees = 0
    userCreatedEvents.forEach((event) => {
      totalAttendees += event.attendees.filter((a) => a.status === "attending").length
    })
    if (totalAttendeesCount) totalAttendeesCount.textContent = totalAttendees

    // Render events
    renderEvents(upcomingEvents, upcomingEventsContainer, "timeline")
    renderEvents(userCreatedEvents, createdEventsContainer, "grid")
    renderInvitations(userInvitedEvents, invitationsContainer)
  } catch (error) {
    console.error("Error loading dashboard data:", error)
    // Show error message
  }
}

// Render events in timeline or grid format
function renderEvents(events, container, format = "timeline") {
  if (!container) return

  // Clear container
  container.innerHTML = ""

  if (events.length === 0) {
    // Show empty state
    const emptyState = document.createElement("div")
    emptyState.className = "empty-state"
    emptyState.innerHTML = `
      <img src="assets/empty-${format === "timeline" ? "calendar" : "events"}.svg" alt="No events">
      <h3>No ${format === "timeline" ? "upcoming" : ""} events</h3>
      <p>${format === "timeline" ? "You don't have any upcoming events." : "You haven't created any events yet."}</p>
      <a href="create-event.html" class="btn btn-primary">Create Event</a>
    `
    container.appendChild(emptyState)
    return
  }

  if (format === "timeline") {
    // Group events by month
    const eventsByMonth = {}
    events.forEach((event) => {
      const date = new Date(event.date)
      const monthYear = date.toLocaleString("default", { month: "long", year: "numeric" })

      if (!eventsByMonth[monthYear]) {
        eventsByMonth[monthYear] = []
      }

      eventsByMonth[monthYear].push(event)
    })

    // Create timeline
    Object.keys(eventsByMonth).forEach((monthYear) => {
      const monthSection = document.createElement("div")
      monthSection.className = "timeline-month"
      monthSection.innerHTML = `<h3>${monthYear}</h3>`

      const eventsList = document.createElement("div")
      eventsList.className = "timeline-events"

      eventsByMonth[monthYear].forEach((event) => {
        const eventDate = new Date(event.date)
        const eventCard = document.createElement("div")
        eventCard.className = "timeline-event-card"
        eventCard.innerHTML = `
          <div class="event-date">
            <div class="date-day">${eventDate.getDate()}</div>
            <div class="date-weekday">${eventDate.toLocaleString("default", { weekday: "short" })}</div>
          </div>
          <div class="event-details">
            <h4>${event.title}</h4>
            <div class="event-meta">
              <span><i class="fas fa-clock"></i> ${event.time.start}${event.time.end ? " - " + event.time.end : ""}</span>
              <span><i class="fas fa-map-marker-alt"></i> ${event.location.city}</span>
            </div>
            <div class="event-attendees">
              <span>${event.attendees.filter((a) => a.status === "attending").length} attending</span>
            </div>
          </div>
          <a href="event-details.html?id=${event._id}" class="event-link"></a>
        `
        eventsList.appendChild(eventCard)
      })

      monthSection.appendChild(eventsList)
      container.appendChild(monthSection)
    })
  } else {
    // Create grid
    const eventsGrid = document.createElement("div")
    eventsGrid.className = "events-grid"

    events.forEach((event) => {
      const eventDate = new Date(event.date)
      const eventCard = document.createElement("div")
      eventCard.className = "event-card"
      eventCard.innerHTML = `
        <div class="event-card-banner">
          <img src="${event.banner || "assets/default-event-banner.jpg"}" alt="${event.title}">
          <div class="event-date-badge">
            <div class="date-month">${eventDate.toLocaleString("default", { month: "short" })}</div>
            <div class="date-day">${eventDate.getDate()}</div>
          </div>
        </div>
        <div class="event-card-content">
          <h3>${event.title}</h3>
          <div class="event-meta">
            <span><i class="fas fa-clock"></i> ${event.time.start}</span>
            <span><i class="fas fa-map-marker-alt"></i> ${event.location.city}</span>
          </div>
          <div class="event-attendees">
            <span>${event.attendees.filter((a) => a.status === "attending").length} attending</span>
          </div>
          <div class="event-actions">
            <a href="event-details.html?id=${event._id}" class="btn btn-sm btn-outline">View Details</a>
            <button class="btn btn-sm btn-icon" title="More Options">
              <i class="fas fa-ellipsis-v"></i>
            </button>
          </div>
        </div>
      `
      eventsGrid.appendChild(eventCard)
    })

    container.appendChild(eventsGrid)
  }
}

// Render invitations
function renderInvitations(events, container) {
  if (!container) return

  // Clear container
  container.innerHTML = ""

  if (events.length === 0) {
    // Show empty state
    const emptyState = document.createElement("div")
    emptyState.className = "empty-state"
    emptyState.innerHTML = `
      <img src="assets/empty-invitations.svg" alt="No invitations">
      <h3>No invitations</h3>
      <p>You don't have any pending invitations.</p>
    `
    container.appendChild(emptyState)
    return
  }

  // Create invitations list
  events.forEach((event) => {
    const eventDate = new Date(event.date)
    const invitation = document.createElement("div")
    invitation.className = "invitation-card"
    invitation.innerHTML = `
      <div class="invitation-details">
        <h3>${event.title}</h3>
        <div class="invitation-meta">
          <span><i class="fas fa-calendar"></i> ${eventDate.toLocaleDateString()}</span>
          <span><i class="fas fa-clock"></i> ${event.time.start}</span>
          <span><i class="fas fa-map-marker-alt"></i> ${event.location.city}</span>
          <span><i class="fas fa-user"></i> Hosted by ${event.creator.name}</span>
        </div>
      </div>
      <div class="invitation-actions">
        <button class="btn btn-sm btn-primary rsvp-btn" data-event-id="${event._id}" data-status="attending">
          <i class="fas fa-check"></i> Accept
        </button>
        <button class="btn btn-sm btn-outline rsvp-btn" data-event-id="${event._id}" data-status="maybe">
          <i class="fas fa-question"></i> Maybe
        </button>
        <button class="btn btn-sm btn-outline rsvp-btn" data-event-id="${event._id}" data-status="not attending">
          <i class="fas fa-times"></i> Decline
        </button>
      </div>
    `
    container.appendChild(invitation)
  })

  // Add event listeners for RSVP buttons
  const rsvpButtons = container.querySelectorAll(".rsvp-btn")
  rsvpButtons.forEach((button) => {
    button.addEventListener("click", async () => {
      const eventId = button.dataset.eventId
      const status = button.dataset.status
      const auth = checkAuth()

      if (!auth) return

      try {
        await eventsAPI.rsvpEvent(eventId, status, auth.token)
        // Refresh dashboard after RSVP
        initDashboard()
      } catch (error) {
        console.error("Error updating RSVP:", error)
      }
    })
  })
}

// Event Listeners
document.addEventListener("DOMContentLoaded", () => {
  // Initialize dashboard
  initDashboard()

  // User dropdown toggle
  if (userDropdownToggle && userDropdown) {
    userDropdownToggle.addEventListener("click", (e) => {
      e.preventDefault()
      userDropdown.classList.toggle("active")
    })

    // Close dropdown when clicking outside
    document.addEventListener("click", (e) => {
      if (!userDropdownToggle.contains(e.target) && !userDropdown.contains(e.target)) {
        userDropdown.classList.remove("active")
      }
    })
  }

  // Logout button
  if (logoutBtn) {
    logoutBtn.addEventListener("click", (e) => {
      e.preventDefault()

      // Clear local storage
      localStorage.removeItem("token")
      localStorage.removeItem("user")

      // Redirect to login page
      window.location.href = "login.html"
    })
  }

  // Tab switching
  if (tabButtons.length && tabContents.length) {
    tabButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const tabId = button.dataset.tab

        // Update active tab button
        tabButtons.forEach((btn) => btn.classList.remove("active"))
        button.classList.add("active")

        // Show active tab content
        tabContents.forEach((content) => {
          content.classList.remove("active")
          if (content.id === `${tabId}-tab`) {
            content.classList.add("active")
          }
        })
      })
    })
  }
})
